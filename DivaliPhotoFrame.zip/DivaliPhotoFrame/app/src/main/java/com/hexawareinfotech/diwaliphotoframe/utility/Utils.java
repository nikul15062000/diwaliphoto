package com.hexawareinfotech.diwaliphotoframe.utility;


import java.util.ArrayList;

/**
 * Created by pmb on 1/6/16.
 */

public class Utils {



    public static ArrayList<String> listIcon = new ArrayList<String>();
    public static ArrayList<String> listName = new ArrayList<String>();
    public static ArrayList<String> listUrl = new ArrayList<String>();

    public static ArrayList<String> listIcon_back = new ArrayList<String>();
    public static ArrayList<String> listName_back = new ArrayList<String>();
    public static ArrayList<String> listUrl_back = new ArrayList<String>();

    public static String DEVICE_ID = "DEVICE_ID";





}

package com.hexawareinfotech.diwaliphotoframe;

/**
 * @author GT
 */
public class GOTOConstants {

    public interface IntentExtras{
        String ACTION_CAMERA = "action-camera";
        String ACTION_GALLERY = "action-gallery";
        String IMAGE_PATH = "image-path";
    }

    public interface PicModes{
        String CAMERA = "Camera";
        String GALLERY = "Gallery";
    }
}

package com.hexawareinfotech.diwaliphotoframe;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import com.hexawareinfotech.diwaliphotoframe.utility.TransparentProgressDialog;
import com.hexawareinfotech.diwaliphotoframe.utility.Utilities;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;

public class MyCreationActivity extends Activity implements AdapterView.OnItemClickListener {

    private String TAG = MyCreationActivity.class.getSimpleName();
    GridView gridSavedGallary;
    Gallary_Adapter gAdp;
    private InterstitialAd mInterstitialAd;
    private AdView mAdView;
    public static int pos;

    TransparentProgressDialog transparentProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation);

        backButton();

        showfullAd();




        mAdView = (AdView) findViewById(R.id.adView);
        gridSavedGallary = (GridView) findViewById(R.id.gridSavedGallary);
        gridSavedGallary.setOnItemClickListener(this);


    }

    private void showfullAd()
    {
        transparentProgressDialog = new TransparentProgressDialog(this, R.drawable.loading);

        transparentProgressDialog.setCancelable(false);
        transparentProgressDialog.show();


        mInterstitialAd = new InterstitialAd(this);

        // set the ad unit ID
        mInterstitialAd.setAdUnitId(getString(R.string.interstitial_full_screen));

        AdRequest adRequest = new AdRequest.Builder()
                .build();

        // Load ads into Interstitial Ads
        mInterstitialAd.loadAd(adRequest);

        mInterstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
                showInterstitial();
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
                Log.i("Ads", "onAdFailedToLoad");
                transparentProgressDialog.dismiss();
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when the ad is displayed.
                Log.i("Ads", "onAdOpened");
                transparentProgressDialog.dismiss();
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
                Log.i("Ads", "onAdLeftApplication");
                transparentProgressDialog.dismiss();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when when the interstitial ad is closed.
                Log.i("Ads", "onAdClosed");
                transparentProgressDialog.dismiss();

            }

        });
    }

    private void showInterstitial() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();


            transparentProgressDialog.dismiss();
        }
    }
    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        Utilities.IMAGEALLARY.clear();
        Utilities.listAllImages(new File("/mnt/sdcard/diwaliDualPhotoFrame/"));
        gAdp = new Gallary_Adapter(MyCreationActivity.this, Utilities.IMAGEALLARY);

        gridSavedGallary.setAdapter(gAdp);
        if (isOnline()) {

            showBannerAd();
        } else {
            mAdView.setVisibility(View.GONE);
        }
    }


    private void showBannerAd() {

        mAdView.setVisibility(View.VISIBLE);
        AdRequest adRequest = new AdRequest.Builder()
                .build();
        mAdView.loadAd(adRequest);

    }

    public void backButton() {

        ImageView back = (ImageView) findViewById(R.id.ivBack);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

        Intent fullscreen = new Intent(MyCreationActivity.this, FullScreenViewActivity.class);
        pos = position;
        fullscreen.putExtra("position", position);
        startActivity(fullscreen);
        finish();
    }

    @Override
    public void onBackPressed() {

        finish();

    }
}
